# hello_wrld

## Getting started 

### `Blockchain part`

```sh
# installation and setup
npm install -g truffle@latest
# initialize project
truffle init
# build project
truffle compile
# Test
truffle test
# deploy
truffle deploy
```

### `Client part`

```sh
mkdir client
cd client
npm create vite@latest
# install dependencies
npm install
# Run the app
npm run dev
```

-----------

@0xJonaseb11
